// This script will update the pets table to include a price column and set default prices
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://igxhqyhyilqdrydyheio.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlneGhxeWh5aWxxZHJ5ZHloZWlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNDAxNTIsImV4cCI6MjA2ODkxNjE1Mn0.fWSbiSahCxBszp7uyQJet6GzJ6-Hfw2enelOX647S8c';

const supabase = createClient(supabaseUrl, supabaseKey);

async function updatePrices() {
  try {
    // First, let's check if the price column exists
    console.log('Checking if price column exists...');
    const { data: columnInfo, error: columnCheckError } = await supabase
      .from('pets')
      .select('*')
      .limit(1);

    if (columnCheckError) throw columnCheckError;
    
    const hasPriceColumn = 'price' in columnInfo[0];
    
    if (!hasPriceColumn) {
      console.log('Price column does not exist, adding it now...');
      // Use the SQL editor in the Supabase dashboard to add the column
      console.log('Please add the price column manually in the Supabase dashboard:');
      console.log('1. Go to https://app.supabase.com/project/igxhqyhyilqdrydyheio/editor');
      console.log('2. Run this SQL in the SQL editor:');
      console.log(`
        ALTER TABLE public.pets 
        ADD COLUMN price NUMERIC(10, 2);
        
        COMMENT ON COLUMN public.pets.price IS 'The price of the pet in local currency';
        
        UPDATE public.pets 
        SET price = 
          CASE 
            WHEN name = 'Buddy' THEN 15000
            WHEN name = 'Whiskers' THEN 8000
            WHEN name = 'Max' THEN 12000
            WHEN name = 'Luna' THEN 10000
            WHEN name = 'Shadow' THEN 6000
            WHEN name = 'Charlie' THEN 9000
            ELSE 0
          END;
      `);
      return;
    }
    
    console.log('✅ Price column exists');
    
    // Update prices for existing pets
    console.log('Updating prices for existing pets...');
    const { data: updateData, error: updateError } = await supabase
      .from('pets')
      .update({
        price: 0
      })
      .is('price', null);
    
    if (updateError) throw updateError;
    
    console.log('✅ Prices updated successfully');
    
    // Verify the changes
    const { data: pets, error: fetchError } = await supabase
      .from('pets')
      .select('id, name, price')
      .limit(5);
      
    if (fetchError) throw fetchError;
    
    console.log('\n=== Updated Pet Data ===');
    console.table(pets);
    
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

updatePrices();
