import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://igxhqyhyilqdrydyheio.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlneGhxeWh5aWxxZHJ5ZHloZWlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNDAxNTIsImV4cCI6MjA2ODkxNjE1Mn0.fWSbiSahCxBszp7uyQJet6GzJ6-Hfw2enelOX647S8c';

const supabase = createClient(supabaseUrl, supabaseKey);

async function fixDatabase() {
  try {
    // Add price column if it doesn't exist
    const { data: addColumn, error: columnError } = await supabase.rpc('exec_sql', {
      sql: `
        DO $$
        BEGIN
          IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                         WHERE table_name = 'pets' AND column_name = 'price') THEN
            ALTER TABLE public.pets ADD COLUMN price NUMERIC(10, 2);
            COMMENT ON COLUMN public.pets.price IS 'The price of the pet in local currency';
          END IF;
        END $$;
      `
    });

    if (columnError) throw columnError;
    console.log('✅ Price column added (if it did not exist)');

    // Update prices for existing pets
    const { data: updateData, error: updateError } = await supabase.rpc('exec_sql', {
      sql: `
        UPDATE public.pets 
        SET price = 
          CASE 
            WHEN name = 'Buddy' THEN 15000
            WHEN name = 'Whiskers' THEN 8000
            WHEN name = 'Max' THEN 12000
            WHEN name = 'Luna' THEN 10000
            WHEN name = 'Shadow' THEN 6000
            WHEN name = 'Charlie' THEN 9000
            ELSE 0
          END
        WHERE price IS NULL;
      `
    });

    if (updateError) throw updateError;
    console.log('✅ Prices updated for existing pets');

    // Verify the changes
    const { data: pets, error: fetchError } = await supabase
      .from('pets')
      .select('id, name, price')
      .limit(5);

    if (fetchError) throw fetchError;
    
    console.log('\n=== Updated Pet Data ===');
    console.table(pets);
    
  } catch (error) {
    console.error('❌ Error fixing database:', error);
  }
}

fixDatabase();
