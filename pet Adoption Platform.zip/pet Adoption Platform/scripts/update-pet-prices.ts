import { createClient } from '@supabase/supabase-js';
// @ts-check
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

// Get the current module's directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load environment variables from project root
dotenv.config({ path: `${__dirname}/../../.env` });

// Supabase configuration - using direct values since env loading is problematic
const supabaseUrl = 'https://igxhqyhyilqdrydyheio.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlneGhxeWh5aWxxZHJ5ZHloZWlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNDAxNTIsImV4cCI6MjA2ODkxNjE1Mn0.fWSbiSahCxBszp7uyQJet6GzJ6-Hfw2enelOX647S8c';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Pet prices mapped by name (in a real app, you might want to use IDs instead)
const petPrices = {
  'Buddy': 15000,
  'Whiskers': 8000,
  'Max': 12000,
  'Luna': 10000,
  'Shadow': 6000,
  'Charlie': 9000
};

async function updatePetPrices() {
  try {
    console.log('Connecting to Supabase...');
    
    // Get all pets
    console.log('Fetching pets from database...');
    const { data: pets, error: fetchError } = await supabase
      .from('pets')
      .select('id, name');

    if (fetchError) {
      throw new Error(`Error fetching pets: ${fetchError.message}`);
    }

    if (!pets || pets.length === 0) {
      console.log('No pets found in the database');
      return;
    }

    console.log(`\nFound ${pets.length} pets in the database`);

    // Update each pet with its price
    for (const [index, pet] of pets.entries()) {
      const price = petPrices[pet.name];
      
      if (price !== undefined) {
        console.log(`\n[${index + 1}/${pets.length}] Updating ${pet.name} (${pet.id})...`);
        console.log(`Setting price to: ₹${price.toLocaleString('en-IN')}`);
        
        const { error: updateError } = await supabase
          .from('pets')
          .update({ price })
          .eq('id', pet.id);

        if (updateError) {
          console.error(`❌ Error updating price for ${pet.name}:`, updateError);
        } else {
          console.log(`✅ Successfully updated ${pet.name}'s price`);
        }
      } else {
        console.warn(`\n⚠️  No price found for pet: ${pet.name} (${pet.id})`);
      }
    }

    console.log('\n🎉 Finished updating pet prices');
  } catch (error) {
    console.error('\n❌ Error updating pet prices:', error);
    process.exit(1);
  }
}

// Run the update
updatePetPrices();
