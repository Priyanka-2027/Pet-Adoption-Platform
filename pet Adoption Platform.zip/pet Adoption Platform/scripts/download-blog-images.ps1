# Script to download sample blog thumbnail images
$imageUrls = @{
    'home-prep' = 'https://images.unsplash.com/photo-1583511655826-057004d788cd?w=400&h=300&fit=crop'
    'dog-training' = 'https://images.unsplash.com/photo-1544568100-847a948585b9?w=400&h=300&fit=crop'
    'pet-vaccinations' = 'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400&h=300&fit=crop'
    'pet-safety' = 'https://images.unsplash.com/photo-1504208434309-cb69f4fe52b0?w=400&h=300&fit=crop'
    'pet-body-language' = 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=400&h=300&fit=crop'
    'adopt-dont-shop' = 'https://images.unsplash.com/photo-1530281700549-e82e7bf110d6?w=400&h=300&fit=crop'
}

# Create thumbnails directory if it doesn't exist
$thumbnailsDir = "public\images\blog\thumbnails"
if (-not (Test-Path -Path $thumbnailsDir)) {
    New-Item -ItemType Directory -Path $thumbnailsDir -Force
}

# Download each image
foreach ($key in $imageUrls.Keys) {
    $url = $imageUrls[$key]
    $outputPath = Join-Path $thumbnailsDir "$key-thumb.jpg"
    
    Write-Host "Downloading $key thumbnail..."
    try {
        Invoke-WebRequest -Uri $url -OutFile $outputPath -ErrorAction Stop
        Write-Host "Successfully downloaded $key thumbnail to $outputPath"
    }
    catch {
        Write-Host "Failed to download $key thumbnail: $_" -ForegroundColor Red
    }
}

Write-Host "\nAll thumbnails have been downloaded to $thumbnailsDir" -ForegroundColor Green
