import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://igxhqyhyilqdrydyheio.supabase.co';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlneGhxeWh5aWxxZHJ5ZHloZWlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNDAxNTIsImV4cCI6MjA2ODkxNjE1Mn0.fWSbiSahCxBszp7uyQJet6GzJ6-Hfw2enelOX647S8c';

const supabase = createClient(supabaseUrl, supabaseKey);

async function checkDatabase() {
  try {
    // Check if price column exists in pets table
    const { data: columnInfo, error: columnError } = await supabase
      .from('information_schema.columns')
      .select('*')
      .eq('table_name', 'pets')
      .eq('column_name', 'price');

    if (columnError) throw columnError;
    
    console.log('=== Price Column Info ===');
    console.log(columnInfo.length > 0 ? 'Price column exists' : 'Price column does NOT exist');
    
    // Check some pet data
    const { data: pets, error: petsError } = await supabase
      .from('pets')
      .select('id, name, price')
      .limit(5);

    if (petsError) throw petsError;
    
    console.log('\n=== Sample Pet Data ===');
    console.table(pets);
    
  } catch (error) {
    console.error('Error checking database:', error);
  }
}

checkDatabase();
