// This script will update the pets table to include a price column and set default prices
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://igxhqyhyilqdrydyheio.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlneGhxeWh5aWxxZHJ5ZHloZWlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNDAxNTIsImV4cCI6MjA2ODkxNjE1Mn0.fWSbiSahCxBszp7uyQJet6GzJ6-Hfw2enelOX647S8c';

const supabase = createClient(supabaseUrl, supabaseKey);

async function updatePrices() {
  try {
    // Add price column if it doesn't exist
    const { data: addColumn, error: columnError } = await supabase.rpc('add_price_column');
    
    if (columnError) {
      console.error('Error adding price column:', columnError);
      return;
    }
    
    console.log('✅ Price column added successfully');
    
    // Update prices for existing pets
    const { data: updateData, error: updateError } = await supabase.rpc('update_pet_prices');
    
    if (updateError) {
      console.error('Error updating prices:', updateError);
      return;
    }
    
    console.log('✅ Prices updated successfully');
    
    // Verify the changes
    const { data: pets, error: fetchError } = await supabase
      .from('pets')
      .select('id, name, price')
      .limit(5);
      
    if (fetchError) throw fetchError;
    
    console.log('\n=== Updated Pet Data ===');
    console.table(pets);
    
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

updatePrices();
