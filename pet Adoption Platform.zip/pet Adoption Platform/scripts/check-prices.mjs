import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://igxhqyhyilqdrydyheio.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlneGhxeWh5aWxxZHJ5ZHloZWlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNDAxNTIsImV4cCI6MjA2ODkxNjE1Mn0.fWSbiSahCxBszp7uyQJet6GzJ6-Hfw2enelOX647S8c';

const supabase = createClient(supabaseUrl, supabaseKey);

async function checkDatabase() {
  try {
    // Check if price column exists
    const { data: columnInfo } = await supabase
      .from('pets')
      .select('*')
      .limit(1);

    console.log('=== Pets Table Columns ===');
    console.log(Object.keys(columnInfo[0]));
    
    // Check some pet data
    const { data: pets } = await supabase
      .from('pets')
      .select('id, name, price')
      .limit(5);
    
    console.log('\n=== Sample Pet Data ===');
    console.table(pets);
    
  } catch (error) {
    console.error('Error checking database:', error);
  }
}

checkDatabase();
