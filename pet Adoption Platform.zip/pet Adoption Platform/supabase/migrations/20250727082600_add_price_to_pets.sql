-- Add price column to pets table
ALTER TABLE public.pets 
ADD COLUMN price DECIMAL(10, 2) DEFAULT 0.00;

-- Update RLS policy to include price
COMMENT ON COLUMN public.pets.price IS 'Adoption price of the pet in local currency';

-- Update the trigger to handle price updates
-- (The existing update_updated_at_column() function will handle the updated_at timestamp)
