-- Add price column to pets table
ALTER TABLE public.pets 
ADD COLUMN price NUMERIC(10, 2);

-- Add comment for the price column
COMMENT ON COLUMN public.pets.price IS 'The price of the pet in local currency';

-- Update existing pets with prices
UPDATE public.pets SET price = 
  CASE 
    WHEN name = 'Buddy' THEN 15000
    WHEN name = 'Whiskers' THEN 8000
    WHEN name = 'Max' THEN 12000
    WHEN name = 'Luna' THEN 10000
    WHEN name = 'Shadow' THEN 6000
    WHEN name = 'Charlie' THEN 9000
    ELSE 0
  END
WHERE price IS NULL;
