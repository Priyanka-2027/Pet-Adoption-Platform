-- Update all pet locations to Indian cities
UPDATE public.pets SET location = 
  CASE 
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 0) THEN 'Mumbai, Maharashtra'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 1) THEN 'Delhi, NCR'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 2) THEN 'Bangalore, Karnataka'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 3) THEN 'Chennai, Tamil Nadu'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 4) THEN 'Kolkata, West Bengal'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 5) THEN 'Hyderabad, Telangana'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 6) THEN 'Pune, Maharashtra'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 7) THEN 'Ahmedabad, Gujarat'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 8) THEN 'Jaipur, Rajasthan'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 9) THEN 'Lucknow, Uttar Pradesh'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 10) THEN 'Chandigarh, Punjab'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 11) THEN 'Coimbatore, Tamil Nadu'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 12) THEN 'Indore, Madhya Pradesh'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 13) THEN 'Kochi, Kerala'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 14) THEN 'Nagpur, Maharashtra'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 15) THEN 'Surat, Gujarat'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 16) THEN 'Visakhapatnam, Andhra Pradesh'
    WHEN id = (SELECT id FROM public.pets ORDER BY id LIMIT 1 OFFSET 17) THEN 'Bhopal, Madhya Pradesh'
    ELSE 'Gurgaon, Haryana'
  END;