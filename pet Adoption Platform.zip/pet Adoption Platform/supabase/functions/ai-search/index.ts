import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { query } = await req.json();
    
    const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openAIApiKey) {
      throw new Error('OpenAI API key not configured');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get all pets to provide context to AI
    const { data: pets, error: petsError } = await supabase
      .from('pets')
      .select('*');

    if (petsError) {
      throw new Error(`Database error: ${petsError.message}`);
    }

    // Create a prompt for OpenAI to understand the query and filter pets
    const systemPrompt = `You are a pet adoption assistant. Given a user's natural language query about pets, you need to filter and rank pets from the provided database.

Available pet data fields:
- name: Pet's name
- species: Dog, Cat, Bird, etc.
- breed: Specific breed
- age: Age in years/months
- size: Small, Medium, Large
- gender: Male, Female
- description: Detailed description
- health_info: Health and medical information
- location: Pet's current location
- status: Available, Adopted, etc.

Return a JSON response with:
1. "matches": Array of pet IDs that match the query, ranked by relevance
2. "explanation": Brief explanation of why these pets match

User query: "${query}"

Pet database:
${JSON.stringify(pets, null, 2)}`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: query }
        ],
        temperature: 0.3,
        response_format: { type: "json_object" }
      }),
    });

    const aiResponse = await response.json();
    console.log('OpenAI API response status:', response.status);
    console.log('OpenAI API response:', JSON.stringify(aiResponse, null, 2));

    if (!response.ok) {
      console.error('OpenAI API error:', aiResponse);
      throw new Error(`OpenAI API error: ${aiResponse.error?.message || 'Unknown error'}`);
    }

    if (!aiResponse.choices || !aiResponse.choices[0] || !aiResponse.choices[0].message) {
      console.error('Invalid OpenAI response structure:', aiResponse);
      throw new Error('Invalid response format from OpenAI API');
    }

    const aiContent = JSON.parse(aiResponse.choices[0].message.content);
    console.log('Parsed AI content:', aiContent);

    // Filter pets based on AI response
    const matchedPets = pets.filter(pet => 
      aiContent.matches && aiContent.matches.includes(pet.id)
    );

    // Sort by the order AI provided
    const sortedPets = aiContent.matches
      ? aiContent.matches
          .map((id: string) => pets.find(pet => pet.id === id))
          .filter(Boolean)
      : [];

    return new Response(JSON.stringify({
      pets: sortedPets,
      explanation: aiContent.explanation,
      totalMatches: sortedPets.length
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in ai-search function:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      pets: [],
      explanation: 'Sorry, I encountered an error processing your search.',
      totalMatches: 0
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});