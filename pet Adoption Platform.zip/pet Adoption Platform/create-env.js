const fs = require('fs');

const envContent = `# OpenAI API Key (Required for AI-generated blog content)
VITE_OPENAI_API_KEY=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

# Supabase Configuration
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlneGhxeWh5aWxxZHJ5ZHloZWlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNDAxNTIsImV4cCI6MjA2ODkxNjE1Mn0.fWSbiSahCxBszp7uyQJet6GzJ6-Hfw2enelOX647S8c

# Application Configuration
PORT=8080

# Environment
NODE_ENV=development`;

fs.writeFileSync('.env', envContent, { encoding: 'utf8', flag: 'w' });
console.log('.env file has been created successfully!');
