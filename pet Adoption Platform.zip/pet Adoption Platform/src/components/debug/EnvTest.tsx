import React from 'react';

const EnvTest = () => {
  const envVars = {
    'VITE_OPENAI_API_KEY': import.meta.env.VITE_OPENAI_API_KEY ? '✅ Set' : '❌ Not Set',
    'VITE_SUPABASE_URL': import.meta.env.VITE_SUPABASE_URL ? '✅ Set' : '❌ Not Set',
    'VITE_SUPABASE_ANON_KEY': import.meta.env.VITE_SUPABASE_ANON_KEY ? '✅ Set' : '❌ Not Set',
    'NODE_ENV': import.meta.env.MODE || 'development',
    'BASE_URL': import.meta.env.BASE_URL || '/',
  };

  return (
    <div className="p-6 max-w-2xl mx-auto bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">Environment Variables Test</h2>
      <div className="space-y-2">
        {Object.entries(envVars).map(([key, value]) => (
          <div key={key} className="flex justify-between py-2 border-b border-gray-200">
            <span className="font-medium text-gray-700">{key}:</span>
            <span className={`font-mono ${value.includes('❌') ? 'text-red-600' : 'text-green-600'}`}>
              {value}
            </span>
          </div>
        ))}
      </div>
      <div className="mt-6 p-4 bg-yellow-50 border-l-4 border-yellow-400">
        <p className="text-yellow-700">
          <strong>Note:</strong> If any variables show as "Not Set", please check your <code>.env</code> file and restart the development server.
        </p>
      </div>
    </div>
  );
};

export default EnvTest;
