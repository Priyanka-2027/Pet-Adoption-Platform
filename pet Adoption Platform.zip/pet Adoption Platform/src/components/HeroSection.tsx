import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
// Placeholder icons (replace with your icon library if available)
const HeartIcon = () => <span role="img" aria-label="heart">❤️</span>;
const SearchIcon = () => <span role="img" aria-label="search">🔍</span>;
const InfoIcon = () => <span role="img" aria-label="info">ℹ️</span>;
import heroImage from "@/assets/hero-pets.jpg";

const HeroSection = () => {
  const navigate = useNavigate();
  
  const handleFindPetsClick = () => {
    navigate('/search');
  };


  return (
    <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <img
        src={heroImage}
        alt="Happy families with their adopted pets"
        className="absolute inset-0 w-full h-full object-cover z-0"
      />
      {/* Overlay */}
      <div className="absolute inset-0 bg-orange-500/40 z-10"></div>

      {/* Content */}
      <div className="relative z-20 max-w-4xl mx-auto px-4 text-center">
        <div className="flex items-center justify-center gap-2 mb-6">
          <span className="text-4xl text-orange-400"><HeartIcon /></span>
          <span className="text-2xl font-bold text-white">PawMatch</span>
        </div>
        <h1 className="text-5xl md:text-6xl font-extrabold text-white mb-4">
          Find Your Perfect <span className="text-orange-400">Companion</span>
        </h1>
        <p className="text-xl text-white/90 mb-8">
          Every pet deserves a loving home. Discover amazing cats and dogs waiting to become part of your family.
        </p>
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4 mb-12">
          <button 
            onClick={handleFindPetsClick}
            className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-lg flex items-center gap-2 text-lg shadow-lg transition-colors duration-200"
          >
            <SearchIcon /> Find Pets
          </button>
        </div>
        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
          <div className="bg-white/20 backdrop-blur-md rounded-lg px-8 py-4 text-center">
            <span className="text-3xl font-bold text-orange-400">500+</span>
            <div className="text-white text-lg">Pets Adopted</div>
          </div>
          <div className="bg-white/20 backdrop-blur-md rounded-lg px-8 py-4 text-center">
            <span className="text-3xl font-bold text-orange-400">50+</span>
            <div className="text-white text-lg">Available Pets</div>
          </div>
          <div className="bg-white/20 backdrop-blur-md rounded-lg px-8 py-4 text-center">
            <span className="text-3xl font-bold text-orange-400">24/7</span>
            <div className="text-white text-lg">Support Available</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;