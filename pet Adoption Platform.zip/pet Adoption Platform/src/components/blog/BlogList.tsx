import { BlogPost } from '@/types/blog';
import BlogCard from './BlogCard';

interface BlogListProps {
  posts: BlogPost[];
  title?: string;
  description?: string;
}

const BlogList = ({ 
  posts, 
  title = 'Pet Care Tips & Articles', 
  description = 'Discover helpful articles and tips for taking care of your pets.' 
}: BlogListProps) => {
  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="inline-block px-3 py-1 text-sm font-semibold text-orange-600 bg-orange-50 rounded-full mb-4">
            Pet Care Resources
          </span>
          <h2 className="text-4xl font-bold text-gray-900 sm:text-5xl mb-4">
            {title}
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-600">
            {description}
          </p>
        </div>
        
        {posts.length > 0 ? (
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {posts.map((post, index) => (
              <div 
                key={post.id} 
                className="animate-fade-in-up"
                style={{
                  animationDelay: `${index * 100}ms`,
                  opacity: 0,
                  animationFillMode: 'forwards'
                }}
              >
                <BlogCard post={post} />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-2xl shadow-sm">
            <div className="mx-auto h-24 w-24 text-gray-300 mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-1">No posts found</h3>
            <p className="text-gray-500">Check back later for new articles.</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default BlogList;
