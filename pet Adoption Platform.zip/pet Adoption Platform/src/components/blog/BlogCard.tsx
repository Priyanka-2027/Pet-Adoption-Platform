import { Link } from 'react-router-dom';
import { BlogPost } from '@/types/blog';
import { Button } from '@/components/ui/button';
import { CalendarDays, Clock, Loader2, User } from 'lucide-react';

interface BlogCardProps {
  post: BlogPost;
}

const BlogCard = ({ post }: BlogCardProps) => {
  return (
    <article className="group bg-white rounded-xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 h-full flex flex-col border border-gray-100 hover:border-orange-100">
      <div className="h-48 overflow-hidden relative bg-gray-50">
        <Link to={`/blog/${post.id}`} className="block h-full">
          <img
            src={post.thumbnailUrl || post.imageUrl || '/images/placeholder-blog.svg'}
            alt={post.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              if (target.src !== '/images/placeholder-blog.svg') {
                target.src = '/images/placeholder-blog.svg';
                target.className = 'w-full h-full object-contain p-8';
              }
            }}
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
            <div className="flex flex-wrap gap-2">
              {post.tags.slice(0, 2).map((tag) => (
                <span 
                  key={tag} 
                  className="text-xs px-2 py-1 bg-white/90 text-orange-700 rounded-full font-medium backdrop-blur-sm"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </Link>
      </div>
      
      <div className="p-6 flex-1 flex flex-col">
        <div className="flex-1">
          <h3 className="text-xl font-bold mb-3 leading-tight text-gray-900 group-hover:text-orange-600 transition-colors line-clamp-2">
            {post.title}
          </h3>
          
          <p className="text-gray-600 mb-4 line-clamp-3 text-sm">
            {post.excerpt}
          </p>
        </div>
        
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center text-xs text-gray-500 space-x-3">
              <div className="flex items-center">
                <User className="h-3.5 w-3.5 mr-1 text-orange-500" />
                <span>{post.author.split(' ')[0]}</span>
              </div>
              <span>•</span>
              <div className="flex items-center">
                <CalendarDays className="h-3.5 w-3.5 mr-1 text-orange-500" />
                <span>{new Date(post.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
              </div>
            </div>
            
            <Link
              to={`/blog/${post.id}`}
              className="inline-flex items-center text-sm font-medium text-orange-600 hover:text-orange-700 transition-colors group/readmore"
            >
              Read more
              <svg
                className="ml-1 h-4 w-4 transition-transform group-hover/readmore:translate-x-1"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </Link>
          </div>
        </div>
      </div>
    </article>
  );
};

export default BlogCard;
