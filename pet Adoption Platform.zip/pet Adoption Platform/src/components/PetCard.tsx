import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, MapPin, Calendar } from "lucide-react";
import { useWishlist } from "@/hooks/useWishlist";
import { useNavigate } from "react-router-dom";
import { getPriceForPet, updatePetPrice } from "@/lib/petUtils";
import { toast } from "@/components/ui/use-toast";

interface Pet {
  id: string;
  name: string;
  breed: string | null;
  age: number | null;
  size: string | null;
  location: string | null;
  images: string[] | null;
  description: string | null;
  species: string;
  gender: string | null;
  price?: number | null;
}

interface PetCardProps {
  pet: Pet;
}

const PetCard = ({ pet }: PetCardProps) => {
  const { toggleWishlist, isInWishlist } = useWishlist();
  const isFavorited = isInWishlist(pet.id);
  const navigate = useNavigate();

  const handleWishlistToggle = () => {
    toggleWishlist(pet.id);
  };

  const handleViewDetails = async () => {
    // If price is missing, try to update it
    if (pet.price === null || pet.price === undefined) {
      const price = getPriceForPet(pet.name);
      if (price !== undefined) {
        const { success } = await updatePetPrice(pet.id, price);
        if (success) {
          toast({
            title: "Pet information updated",
            description: `Price updated for ${pet.name}`,
          });
        }
      }
    }
    navigate(`/pet/${pet.id}`);
  };

  return (
    <Card className="group bg-gradient-card shadow-card hover:shadow-glow transition-all duration-300 hover:scale-105 overflow-hidden">
      <div className="relative">
        <img 
          src={pet.images?.[0] || "/placeholder.svg"} 
          alt={pet.name}
          className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
        />
        <Button
          variant="ghost"
          size="icon"
          className={`absolute top-4 right-4 bg-background/80 backdrop-blur-sm hover:bg-background ${
            isFavorited ? 'text-red-500' : 'text-muted-foreground'
          }`}
          onClick={handleWishlistToggle}
        >
          <Heart className={`h-5 w-5 ${isFavorited ? 'fill-current' : ''}`} />
        </Button>
        <Badge 
          variant="default"
          className="absolute bottom-4 left-4 bg-primary text-primary-foreground font-semibold shadow-md"
        >
          {pet.size}
        </Badge>
      </div>
      
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-xl font-bold text-card-foreground">{pet.name}</h3>
          {pet.age !== null && (
            <div className="flex items-center text-muted-foreground text-sm">
              <Calendar className="h-4 w-4 mr-1" />
              {pet.age} {pet.age === 1 ? 'year' : 'years'} old
            </div>
          )}
        </div>
        
        <p className="text-muted-foreground mb-3">{pet.breed || 'Mixed breed'}</p>
        
        <div className="flex justify-between items-center mb-3">
          {pet.price ? (
            <div className="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-sm font-medium">
              ₹{pet.price.toLocaleString('en-IN')}
            </div>
          ) : (
            <div className="text-sm text-muted-foreground">Price on request</div>
          )}
        </div>
        <p className="text-muted-foreground text-sm line-clamp-3 mb-3 min-h-[60px]">
          {pet.description}
        </p>
        
        <div className="flex items-center text-muted-foreground text-sm">
          <MapPin className="h-4 w-4 mr-1" />
          {pet.location || 'Location not specified'}
        </div>
      </CardContent>
      
      <CardFooter className="p-6 pt-0">
        <Button
          onClick={handleViewDetails}
          className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-lg mt-4"
        >
          View Details
        </Button>
      </CardFooter>
    </Card>
  );
};

export default PetCard;