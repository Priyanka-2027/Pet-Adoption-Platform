import PetCard from "./PetCard";
import { Button } from "@/components/ui/button";
import pet1 from "@/assets/pet-1.jpg";
import pet2 from "@/assets/pet-2.jpg";
import pet3 from "@/assets/pet-3.jpg";

// Mock data for pets
const mockPets = [
  {
    id: "b3b8c7e2-8c2a-4e2a-9c2a-8c2a4e2a9c2a",
    name: "Buddy",
    breed: "Golden Retriever",
    age: 2,
    size: "Large",
    location: "Mumbai, Maharashtra",
    images: [pet1],
    description: "Buddy is a friendly and energetic golden retriever who loves playing fetch and swimming. He's great with kids and other dogs.",
    species: "Dog",
    gender: "Male",
    price: 15000
  },
  {
    id: "c4d5e6f7-1a2b-3c4d-5e6f-7a8b9c0d1e2f",
    name: "Whiskers",
    breed: "Orange Tabby",
    age: 3,
    size: "Medium",
    location: "Delhi, NCR",
    images: [pet2],
    description: "Whiskers is a calm and affectionate cat who enjoys sunny windowsills and gentle pets. Perfect for a quiet home.",
    species: "Cat",
    gender: "Female",
    price: 8000
  },
  {
    id: "e7f8a9b0-1c2d-3e4f-5a6b-7c8d9e0f1a2b",
    name: "Max",
    breed: "Beagle Mix",
    age: 4,
    size: "Medium",
    location: "Bangalore, Karnataka",
    images: [pet3],
    description: "Max is a loyal companion who loves long walks and treats. He's well-trained and ready for his forever family.",
    species: "Dog",
    gender: "Male",
    price: 12000
  },
  {
    id: "f1a2b3c4-5d6e-7f8a-9b0c-1d2e3f4a5b6c",
    name: "Luna",
    breed: "Husky",
    age: 1,
    size: "Large",
    location: "Chennai, Tamil Nadu",
    images: [pet1],
    description: "Luna is a playful puppy with bright blue eyes. She needs an active family who can keep up with her energy.",
    species: "Dog",
    gender: "Female",
    price: 10000
  },
  {
    id: "a1b2c3d4-5e6f-7a8b-9c0d-1e2f3a4b5c6d",
    name: "Shadow",
    breed: "Black Cat",
    age: 5,
    size: "Small",
    location: "Kolkata, West Bengal",
    images: [pet2],
    description: "Shadow is a mysterious and independent cat who shows affection on his own terms. Very low maintenance.",
    species: "Cat",
    gender: "Male",
    price: 6000
  },
  {
    id: "d5e6f7a8-9b0c-1d2e-3f4a-5b6c7d8e9f0a",
    name: "Charlie",
    breed: "Labrador Mix",
    age: 6,
    size: "Large",
    location: "Hyderabad, Telangana",
    images: [pet3],
    description: "Charlie is a gentle senior dog who would love a peaceful home where he can relax and enjoy his golden years.",
    species: "Dog",
    gender: "Male",
    price: 9000
  }
];

const PetGrid = () => {
  return (
    <section className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Meet Our Pets
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            These loving animals are waiting for their forever homes. Could one of them be perfect for you?
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {mockPets.map((pet) => (
            <PetCard key={pet.id} pet={pet} />
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button variant="default" size="lg">
            View All Pets
          </Button>
        </div>
      </div>
    </section>
  );
};

export default PetGrid;