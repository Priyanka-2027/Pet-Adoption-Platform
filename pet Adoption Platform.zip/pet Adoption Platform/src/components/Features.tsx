import { Card, CardContent } from "@/components/ui/card";
import { Search, Heart, Home, Users } from "lucide-react";

const features = [
  {
    icon: Search,
    title: "Easy Search",
    description: "Find your perfect pet using our advanced filters for breed, age, size, and location."
  },
  {
    icon: Heart,
    title: "Save Favorites",
    description: "Keep track of pets you love and get notified when similar pets become available."
  },
  {
    icon: Home,
    title: "Home Visits",
    description: "Schedule convenient home visits to ensure the perfect match for your family."
  },
  {
    icon: Users,
    title: "Support Network",
    description: "Join our community of pet owners and get ongoing support throughout the adoption process."
  }
];

const Features = () => {
  return (
    <section className="py-16 bg-muted/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Why Choose PawMatch?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            We make pet adoption simple, safe, and rewarding for both pets and families.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="bg-gradient-card shadow-card hover:shadow-soft transition-all duration-300 hover:scale-105 text-center border-0">
                <CardContent className="p-8">
                  <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
                    <Icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Features;