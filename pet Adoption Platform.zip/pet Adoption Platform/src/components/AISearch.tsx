import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, Sparkles } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import PetCard from './PetCard';

interface Pet {
  id: string;
  name: string;
  species: string;
  breed?: string;
  age?: number;
  size?: string;
  gender?: string;
  description?: string;
  images?: string[];
  location?: string;
  status?: string;
}

interface AISearchResult {
  pets: Pet[];
  explanation: string;
  totalMatches: number;
}

const AISearch = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<AISearchResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSearch = async () => {
    if (!query.trim()) return;

    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('ai-search', {
        body: { query }
      });

      if (error) throw error;

      setResults(data);
      
      if (data.totalMatches === 0) {
        toast({
          title: "No matches found",
          description: data.explanation,
        });
      }
    } catch (error) {
      console.error('Search error:', error);
      toast({
        title: "Search Error",
        description: "Failed to search pets. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            AI Pet Search
          </CardTitle>
          <CardDescription>
            Ask me anything about our pets! Try: "I want a small dog that's good with kids" or "Show me cats under 2 years old"
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              placeholder="Describe the pet you're looking for..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              className="flex-1"
            />
            <Button 
              onClick={handleSearch} 
              disabled={isLoading || !query.trim()}
              className="min-w-[100px]"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Searching
                </div>
              ) : (
                <>
                  <Search className="h-4 w-4 mr-2" />
                  Search
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {results && (
        <div className="space-y-4">
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <Badge variant="secondary" className="text-sm">
                  {results.totalMatches} matches found
                </Badge>
              </div>
              <p className="text-muted-foreground mt-2">{results.explanation}</p>
            </CardContent>
          </Card>

          {results.pets.length > 0 && (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.pets.map((pet) => (
                <PetCard
                  key={pet.id}
                  pet={{
                    id: pet.id,
                    name: pet.name,
                    breed: pet.breed || pet.species,
                    age: pet.age || null,
                    size: pet.size || null,
                    location: pet.location || null,
                    images: pet.images || null,
                    description: pet.description || null,
                    species: pet.species,
                    gender: pet.gender || null
                  }}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AISearch;