export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  imageUrl: string; // Main image URL for the blog post
  thumbnailUrl: string; // Thumbnail image URL for cards/lists
  author: string;
  date: string;
  readTime: string;
  tags: string[];
  metaDescription?: string; // For SEO
}

export const sampleBlogPosts: BlogPost[] = [
  // Pet Care & Training
  {
    id: 'home-prep',
    title: 'How to Prepare Your Home for a New Pet',
    excerpt: 'Get your home ready for your new furry family member with this comprehensive room-by-room guide to pet-proofing.',
    imageUrl: '/images/blog/full/home-prep.jpg',
    thumbnailUrl: '/images/blog/thumbnails/home-prep-thumb.jpg',
    author: 'Sarah Johnson',
    date: '2025-07-15',
    readTime: '8 min read',
    tags: ['Pet Care', 'New Pet', 'Home Safety'],
    content: `
      <h2>Creating a Safe and Welcoming Space for Your New Pet</h2>
      <p>Bringing a new pet home is an exciting time, but it's important to ensure your living space is safe and comfortable for your new family member. Here's a room-by-room guide to help you prepare:</p>
      
      <h3>Living Room</h3>
      <ul>
        <li>Secure loose wires and cables that could be chewed</li>
        <li>Remove small objects that could be choking hazards</li>
        <li>Use baby gates to block off unsafe areas if needed</li>
        <li>Cover or secure electrical outlets</li>
      </ul>
      
      <h3>Kitchen</h3>
      <ul>
        <li>Keep trash cans covered or in a latched cabinet</li>
        <li>Store cleaning supplies and chemicals out of reach</li>
        <li>Be mindful of foods that are toxic to pets (chocolate, grapes, onions, etc.)</li>
        <li>Use childproof latches on lower cabinets</li>
      </ul>
      
      <h3>Bedroom</h3>
      <ul>
        <li>Designate a comfortable sleeping area for your pet</li>
        <li>Remove small items from nightstands and dressers</li>
        <li>Keep medications and personal care products secured</li>
        <li>Consider using a crate for safe alone time</li>
      </ul>
      
      <h3>Bathroom</h3>
      <ul>
        <li>Keep toilet lids closed to prevent drinking or falling in</li>
        <li>Store medications, cosmetics, and cleaning products securely</li>
        <li>Use non-slip mats in the bathtub</li>
      </ul>
      
      <h3>General Tips</h3>
      <ul>
        <li>Create a designated "safe space" for your pet to retreat to</li>
        <li>Have essential supplies ready (food, water bowls, bed, toys, etc.)</li>
        <li>Research pet-friendly plants if you have houseplants</li>
        <li>Consider installing window screens if you open windows</li>
      </ul>
      
      <p>Taking these steps before bringing your new pet home will help create a safe environment and make the transition smoother for everyone involved.</p>
    `
  },
  {
    id: 'dog-training',
    title: 'Basic Dog Training Tips for New Adopters',
    excerpt: 'Start your journey with your new best friend on the right paw with these essential training techniques.',
    imageUrl: '/images/blog/full/dog-training.jpg',
    thumbnailUrl: '/images/blog/thumbnails/dog-training-thumb.jpg',
    author: 'Trainer Mike Roberts',
    date: '2025-07-20',
    readTime: '10 min read',
    tags: ['dogs', 'training', 'behavior'],
    content: `
      <h2>Essential Training for Your New Canine Companion</h2>
      <p>Training is essential for building a strong bond with your new dog and ensuring they become a well-behaved family member. Here are the fundamental training techniques every new dog owner should know:</p>
      
      <h3>1. Positive Reinforcement</h3>
      <p>Reward good behavior with treats, praise, or playtime. This helps your dog understand what you want them to do.</p>
      
      <h3>2. Basic Commands</h3>
      <p>Start with these essential commands:</p>
      <ul>
        <li><strong>Sit:</strong> Hold a treat above your dog's nose and move it back over their head.</li>
        <li><strong>Stay:</strong> Ask your dog to sit, then hold your hand up and say "stay."</li>
        <li><strong>Come:</strong> Use a happy voice and reward when they come to you.</li>
        <li><strong>Leave it:</strong> Essential for preventing them from picking up dangerous items.</li>
      </ul>
      
      <h3>3. Crate Training</h3>
      <p>Make the crate a positive space by feeding meals inside and providing comfortable bedding. Never use the crate for punishment.</p>
      
      <h3>4. Leash Training</h3>
      <p>Teach loose-leash walking by stopping when they pull and only moving forward when the leash is loose.</p>
      
      <h3>5. Socialization</h3>
      <p>Expose your dog to different people, animals, and environments during their first few months to build confidence.</p>
      
      <h3>6. House Training</h3>
      <p>Establish a consistent schedule for bathroom breaks and reward them for going in the right place.</p>
      
      <h3>7. Bite Inhibition</h3>
      <p>Teach your puppy to control the force of their bite through gentle play and redirection to appropriate toys.</p>
      
      <h3>8. Patience and Consistency</h3>
      <p>Training takes time. Be patient, consistent with your commands, and keep training sessions short and fun.</p>
      
      <p>Remember, training should be fun for both you and your dog. Keep sessions short (5-10 minutes) and end on a positive note. If you're struggling, don't hesitate to seek help from a professional dog trainer.</p>
    `,
  },
  
  // Health & Wellness
  {
    id: 'pet-vaccinations',
    title: 'Vaccinations Your Pet Needs (and Why They Matter)',
    excerpt: 'A complete guide to essential vaccinations for dogs and cats at every life stage.',
    imageUrl: '/images/blog/full/pet-vaccinations.jpg',
    thumbnailUrl: '/images/blog/thumbnails/pet-vaccinations-thumb.jpg',
    author: 'Dr. Emily Chen',
    date: '2025-07-18',
    readTime: '7 min read',
    tags: ['health', 'vaccines', 'preventive care'],
    content: `
      <h2>Essential Vaccinations for Your Pet's Health</h2>
      <p>Vaccinations are a crucial part of preventive healthcare for pets, protecting them from serious and potentially fatal diseases. This guide covers the essential vaccinations your dog or cat needs at different life stages.</p>
      
      <h3>Core Vaccines for Dogs</h3>
      <p>These vaccines are considered essential for all dogs:</p>
      <ul>
        <li><strong>Rabies:</strong> Required by law in most areas, protects against this fatal virus</li>
        <li><strong>Distemper:</strong> Protects against a highly contagious and often fatal disease</li>
        <li><strong>Parvovirus:</strong> Essential for puppies, as parvo is often deadly</li>
        <li><strong>Adenovirus (Canine Hepatitis):</strong> Protects against liver disease</li>
      </ul>
      
      <h3>Core Vaccines for Cats</h3>
      <p>Essential vaccines for all felines include:</p>
      <ul>
        <li><strong>Rabies:</strong> Legally required in many areas</li>
        <li><strong>Feline Viral Rhinotracheitis:</strong> Protects against severe upper respiratory infections</li>
        <li><strong>Calicivirus:</strong> Prevents respiratory disease and oral ulcers</li>
        <li><strong>Panleukopenia (Feline Distemper):</strong> A highly contagious and often fatal disease</li>
      </ul>
      
      <h3>Non-Core Vaccines (Based on Lifestyle)</h3>
      <p>These may be recommended based on your pet's risk factors:</p>
      <ul>
        <li><strong>For Dogs:</strong> Bordetella (kennel cough), Leptospirosis, Lyme disease, Canine influenza</li>
        <li><strong>For Cats:</strong> Feline leukemia (FeLV), Feline immunodeficiency virus (FIV), Chlamydophila</li>
      </ul>
      
      <h3>Vaccination Schedule</h3>
      <p>Typical vaccination timeline:</p>
      <ul>
        <li><strong>6-8 weeks:</strong> First round of puppy/kitten vaccines</li>
        <li><strong>10-12 weeks:</strong> Booster shots</li>
        <li><strong>14-16 weeks:</strong> Final puppy/kitten boosters and rabies vaccine</li>
        <li><strong>Annually or every 3 years:</strong> Booster shots as recommended by your vet</li>
      </ul>
      
      <h3>Why Vaccinations Matter</h3>
      <ul>
        <li>Prevent life-threatening diseases</li>
        <li>Protect other pets in the community</li>
        <li>Some vaccines are required by law (like rabies)</li>
        <li>More cost-effective than treating the diseases they prevent</li>
      </ul>
      
      <p>Always consult with your veterinarian to develop a vaccination schedule tailored to your pet's specific needs and lifestyle.</p>
    `,
  },
  {
    id: 'pet-safety',
    title: 'How to Keep Your Pet Safe During Summer/Winter',
    excerpt: 'Seasonal safety tips to protect your pets from extreme weather conditions throughout the year.',
    imageUrl: '/images/blog/full/seasonal-safety.jpg',
    thumbnailUrl: '/images/blog/thumbnails/seasonal-safety-thumb.jpg',
    author: 'Dr. James Wilson',
    date: '2025-07-15',
    readTime: '6 min read',
    tags: ['safety', 'seasonal care', 'health'],
    content: `
      <h2>Seasonal Pet Safety Guide</h2>
      <p>Extreme temperatures can be dangerous for pets. Here's how to keep your furry friends safe and comfortable all year round.</p>
      
      <h3>Summer Safety Tips</h3>
      <h4>Heat Protection</h4>
      <ul>
        <li>Never leave pets in a parked car, even with windows cracked</li>
        <li>Provide plenty of fresh water and shade when outside</li>
        <li>Walk dogs in the early morning or evening to avoid peak heat</li>
        <li>Test pavement temperature with your hand - if it's too hot for you, it's too hot for paws</li>
      </ul>
      
      <h4>Water Safety</h4>
      <ul>
        <li>Not all dogs are natural swimmers - introduce water gradually</li>
        <li>Use pet life jackets for boating or swimming</li>
        <li>Rinse off chlorine or saltwater after swimming</li>
      </ul>
      
      <h3>Winter Safety Tips</h3>
      <h4>Cold Weather Protection</h4>
      <ul>
        <li>Limit time outdoors in freezing temperatures</li>
        <li>Consider a pet sweater or coat for short-haired breeds</li>
        <li>Wipe paws after walks to remove ice, salt, and antifreeze</li>
        <li>Check under car hoods and wheel wells where outdoor cats might seek warmth</li>
      </ul>
      
      <h4>Holiday Hazards</h4>
      <ul>
        <li>Keep holiday plants (poinsettias, holly, mistletoe) out of reach</li>
        <li>Secure Christmas trees to prevent tipping</li>
        <li>Avoid tinsel and small ornaments that could be swallowed</li>
      </ul>
      
      <h3>Year-Round Safety</h3>
      <ul>
        <li>Keep antifreeze stored safely and clean up spills immediately (it's highly toxic)</li>
        <li>Be cautious with seasonal decorations and electrical cords</li>
        <li>Update your pet's ID tags and microchip information</li>
        <li>Have an emergency kit ready with pet supplies</li>
      </ul>
      
      <p>Remember, if you're uncomfortable in the weather, your pet probably is too. When in doubt, keep them indoors in a temperature-controlled environment.</p>
    `,
  },
  
  // Behavior & Psychology
  {
    id: 'pet-body-language',
    title: 'Understanding Pet Body Language',
    excerpt: 'Learn to read the subtle signals your pet is sending through their body language and behavior.',
    imageUrl: '/images/blog/full/pet-body-language.jpg',
    thumbnailUrl: '/images/blog/thumbnails/pet-body-language-thumb.jpg',
    author: 'Animal Behaviorist Lisa Wong',
    date: '2025-07-10',
    readTime: '9 min read',
    tags: ['behavior', 'communication', 'pet psychology'],
    content: `
      <h2>Decoding Your Pet's Silent Communication</h2>
      <p>Pets communicate volumes through their body language, but their signals can be subtle. Learning to read these cues will help you better understand your pet's emotions and needs.</p>
      
      <h3>Dog Body Language</h3>
      <h4>Happy/Relaxed</h4>
      <ul>
        <li>Loose, wiggly body with a gently wagging tail</li>
        <li>Relaxed, open mouth (looks like a smile)</li>
        <li>Ears in natural position</li>
        <li>Soft, squinty eyes</li>
      </ul>
      
      <h4>Anxious/Stressed</h4>
      <ul>
        <li>Yawning, lip licking, or nose licking</li>
        <li>Whale eye (showing the whites of the eyes)</li>
        <li>Tucked tail or stiff, slow wag</li>
        <li>Lowered head and body, ears back</li>
      </ul>
      
      <h4>Aggressive/Defensive</h4>
      <ul>
        <li>Stiff body posture</li>
        <li>Direct, hard stare</li>
        <li>Raised hackles (fur standing up)</li>
        <li>Bared teeth with wrinkled nose</li>
      </ul>
      
      <h3>Cat Body Language</h3>
      <h4>Content/Relaxed</h4>
      <ul>
        <li>Ears forward, relaxed whiskers</li>
        <li>Slow blinking (a "kitty kiss")</li>
        <li>Kneading with paws</li>
        <li>Tail held high with a slight curve at the tip</li>
      </ul>
      
      <h4>Anxious/Stressed</h4>
      <ul>
        <li>Flattened ears to the side or back</li>
        <li>Dilated pupils</li>
        <li>Tucked tail or puffed-up tail</li>
        <li>Hiding or trying to make themselves look smaller</li>
      </ul>
      
      <h4>Aggressive/Defensive</h4>
      <ul>
        <li>Ears flat against the head</li>
        <li>Arched back with fur standing up</li>
        <li>Hissing, growling, or spitting</li>
        <li>Tail lashing or thrashing</li>
      </ul>
      
      <h3>Small Mammal Body Language</h3>
      <ul>
        <li><strong>Rabbits:</strong> Binkying (jumping and twisting) shows happiness; thumping indicates danger or displeasure</li>
        <li><strong>Guinea Pigs:</strong> "Popcorning" (jumping straight up) shows excitement; teeth chattering signals annoyance</li>
        <li><strong>Hamsters:</strong> Grooming indicates comfort; standing on hind legs shows curiosity</li>
      </ul>
      
      <h3>Bird Body Language</h3>
      <ul>
        <li>Preening: Normal grooming behavior, shows contentment</li>
        <li>Fluffed feathers: Could indicate illness or trying to keep warm</li>
        <li>Beak grinding: A sign of relaxation, often before sleep</li>
        <li>Wing flapping: Exercise or a sign of happiness</li>
      </ul>
      
      <p>Remember that every pet is an individual, so you may need to adjust this list based on your specific pet's needs. Spend time observing your pet to learn their unique communication style.</p>
    `,
  },
  
  // Adoption & Rescue
  {
    id: 'adopt-dont-shop',
    title: 'Why Adopt Instead of Buy?',
    excerpt: 'Discover the many benefits of pet adoption and how you can make a difference in an animal\'s life.',
    imageUrl: '/images/placeholder-blog.svg',
    thumbnailUrl: '/images/blog/thumbnails/adopt-dont-shop-thumb.jpg',
    author: 'Sarah Miller, Shelter Director',
    date: '2025-07-05',
    readTime: '5 min read',
    tags: ['adoption', 'rescue', 'animal welfare'],
    content: `
      <h2>The Life-Saving Impact of Pet Adoption</h2>
      <p>Choosing to adopt a pet from a shelter or rescue organization has far-reaching benefits that extend beyond just giving one animal a home. Here's why adoption should be your first choice when adding a pet to your family.</p>
      
      <h3>You Save Lives</h3>
      <ul>
        <li>Adopting from a shelter directly saves that animal's life</li>
        <li>You create space for another animal to be rescued</li>
        <li>You help reduce pet overpopulation by not supporting breeding operations</li>
        <li>Many shelters are overcrowded, and adoption helps them continue their lifesaving work</li>
      </ul>
      
      <h3>Financial Benefits</h3>
      <ul>
        <li>Adoption fees are typically much lower than purchasing from a breeder</li>
        <li>Most adopted pets are already spayed/neutered</li>
        <li>Vaccinations and microchipping are often included</li>
        <li>Many shelters provide initial veterinary care and behavioral assessments</li>
      </ul>
      
      <h3>You Get a Great Pet</h3>
      <ul>
        <li>Shelter pets are just as loving, intelligent, and loyal as any other pet</li>
        <li>Many are already house-trained and know basic commands</li>
        <li>Shelter staff can help match you with a pet that fits your lifestyle</li>
        <li>You can find pets of all ages, from playful puppies to calm seniors</li>
      </ul>
      
      <h3>Common Myths About Shelter Pets</h3>
      <h4>"Shelter pets have behavioral problems"</h4>
      <p>Most pets end up in shelters due to human issues (moving, allergies, lack of time) - not because of anything they did wrong.</p>
      
      <h4>"I can't find purebred pets in shelters"</h4>
      <p>About 25% of shelter dogs are purebred, and there are also breed-specific rescues for nearly every breed.</p>
      
      <h4>"Shelter pets are less healthy"</h4>
      <p>Shelters provide veterinary care and are transparent about any health issues. Many pets come from loving homes and are in excellent health.</p>
      
      <h3>How to Adopt Responsibly</h3>
      <ol>
        <li>Research different shelters and rescues in your area</li>
        <li>Consider what type of pet fits your lifestyle (size, energy level, grooming needs)</li>
        <li>Be patient - finding the right match might take time</li>
        <li>Prepare your home before bringing your new pet home</li>
        <li>Commit to the lifelong responsibility of pet ownership</li>
      </ol>
      
      <h3>Other Ways to Help If You Can't Adopt</h3>
      <ul>
        <li>Foster a pet temporarily</li>
        <li>Volunteer at your local shelter</li>
        <li>Donate supplies or money</li>
        <li>Share adoptable pets on social media</li>
        <li>Spay/neuter your own pets to prevent unwanted litters</li>
      </ul>
      
      <p>By choosing to adopt, you're not just getting a pet - you're becoming part of the solution to pet overpopulation and giving a deserving animal a second chance at happiness.</p>
    `
  },
  
  // Tips & Resources
  {
    id: 'pet-supplies',
    title: 'Essential Pet Supplies Checklist',
    excerpt: 'The ultimate checklist of must-have items for new pet owners, from food to toys to grooming tools.',
    content: `
      <h2>The Complete New Pet Shopping List</h2>
      <p>Preparing for a new pet? This comprehensive checklist ensures you have everything you need to welcome your new family member home.</p>
      
      <h3>Food & Water Essentials</h3>
      <ul>
        <li><strong>High-quality pet food</strong> (appropriate for age, size, and species)</li>
        <li><strong>Stainless steel or ceramic bowls</strong> (avoid plastic which can harbor bacteria)</li>
        <li><strong>Automatic water fountain</strong> (especially for cats who prefer running water)</li>
        <li><strong>Food storage containers</strong> to keep food fresh</li>
        <li><strong>Treats</strong> for training and rewards</li>
      </ul>
      
      <h3>Comfort & Bedding</h3>
      <ul>
        <li><strong>Comfortable bed</strong> with washable cover</li>
        <li><strong>Blankets</strong> for extra warmth and comfort</li>
        <li><strong>Crate or carrier</strong> for safe transport and training</li>
        <li><strong>Cat tree or scratching post</strong> (for feline friends)</li>
        <li><strong>Hiding spots</strong> for small animals</li>
      </ul>
      
      <h3>Grooming Supplies</h3>
      <ul>
        <li><strong>Brush/comb</strong> appropriate for your pet's coat type</li>
        <li><strong>Pet-safe shampoo</strong> and conditioner</li>
        <li><strong>Nail clippers</strong> or grinder</li>
        <li><strong>Toothbrush</strong> and pet toothpaste</li>
        <li><strong>Ear cleaning solution</strong> and cotton balls</li>
      </ul>
      
      <h3>Health & Safety</h3>
      <ul>
        <li><strong>Collar with ID tags</strong> (include your contact information)</li>
        <li><strong>Microchip</strong> (if not already provided)</li>
        <li><strong>First aid kit</strong> for pets</li>
        <li><strong>Flea/tick prevention</strong> (as recommended by your vet)</li>
        <li><strong>Pet insurance information</strong> or savings plan</li>
      </ul>
      
      <h3>Toys & Enrichment</h3>
      <ul>
        <li><strong>Interactive toys</strong> for mental stimulation</li>
        <li><strong>Chew toys</strong> (for dogs)</li>
        <li><strong>Puzzle feeders</strong> to make mealtime engaging</li>
        <li><strong>Catnip toys</strong> (for cats)</li>
        <li><strong>Tunnels and hideaways</strong> (for small animals)</li>
      </ul>
      
      <h3>Cleaning Supplies</h3>
      <ul>
        <li><strong>Enzyme cleaner</strong> for accidents</li>
        <li><strong>Litter box and litter</strong> (for cats)</li>
        <li><strong>Poop bags</strong> (for dogs)</li>
        <li><strong>Pet-safe cleaning wipes</strong></li>
        <li><strong>Odor neutralizer</strong></li>
      </ul>
      
      <h3>Training Essentials</h3>
      <ul>
        <li><strong>Clicker</strong> for training</li>
        <li><strong>Training treats</strong></li>
        <li><strong>Leash and harness</strong> (for dogs)</li>
        <li><strong>Potty training pads</strong> (if applicable)</li>
        <li><strong>Training book or app</strong> for guidance</li>
      </ul>
      
      <h3>Travel & Outdoors</h3>
      <ul>
        <li><strong>Seat belt harness or travel carrier</strong> for car rides</li>
        <li><strong>Travel water bottle</strong> and collapsible bowl</li>
        <li><strong>Pet life jacket</strong> (if near water)</li>
        <li><strong>Pet-safe sunscreen</strong> (for light-colored pets)</li>
        <li><strong>Winter coat or booties</strong> (for cold climates)</li>
      </ul>
      
      <h3>Emergency Preparedness</h3>
      <ul>
        <li><strong>Emergency contact list</strong> (vet, emergency vet, poison control)</li>
        <li><strong>Pet first aid guide</strong></li>
        <li><strong>Extra supply of medications</strong> (if applicable)</li>
        <li><strong>Recent photo of your pet</strong> (in case they get lost)</li>
        <li><strong>Emergency evacuation plan</strong> that includes your pet</li>
      </ul>
      
      <p>Remember that every pet is unique, so you may need to adjust this list based on your specific pet's needs. When in doubt, consult with your veterinarian or a professional pet care specialist.</p>
    `,
    imageUrl: '/images/placeholder-blog.svg',
    thumbnailUrl: '/images/blog/thumbnails/pet-supplies-thumb.jpg',
    author: 'The Waggle Team',
    date: '2025-07-01',
    readTime: '6 min read',
    tags: ['new pet', 'supplies', 'checklist']
  },
  
  // Awareness & Advocacy
  {
    id: 'pet-myths',
    title: 'Common Pet Myths Debunked',
    excerpt: 'We separate fact from fiction on the most common misconceptions about pet care and behavior.',
    content: `
      <h2>Pet Myths Busted: The Truth Behind Common Pet Beliefs</h2>
      <p>There's a lot of pet advice out there, but not all of it is accurate. Let's separate fact from fiction on some of the most persistent pet myths.</p>
      
      <h3>Myth 1: "A wagging tail means a happy dog."</h3>
      <p><strong>The Truth:</strong> While a loose, relaxed wag often indicates happiness, tail wagging can communicate many emotions including anxiety, fear, or even aggression. The position of the tail and the speed of the wag provide important context.</p>
      
      <h3>Myth 2: "Cats always land on their feet."</h3>
      <p><strong>The Truth:</strong> While cats have a "righting reflex" that helps them orient themselves during falls, they don't always land on their feet, especially from shorter distances. Falls can still cause serious injuries, a condition known as "high-rise syndrome."</p>
      
      <h3>Myth 3: "You can't teach an old dog new tricks."</h3>
      <p><strong>The Truth:</strong> Dogs of any age can learn new things! While puppies may learn slightly faster, older dogs often have better focus and self-control, making them excellent students.</p>
      
      <h3>Myth 4: "Cats are low-maintenance pets."</h3>
      <p><strong>The Truth:</strong> While cats may be more independent than dogs, they still require significant care including daily play, mental stimulation, regular veterinary check-ups, and a clean environment. Many behavior problems stem from cats not receiving enough attention or environmental enrichment.</p>
      
      <h3>Myth 5: "Dogs eat grass when they're sick."</h3>
      <p><strong>The Truth:</strong> While some dogs may eat grass when nauseous, many dogs eat grass simply because they enjoy it. In most cases, occasional grass-eating is normal behavior and not a cause for concern unless it's excessive or accompanied by other symptoms.</p>
      
      <h3>Myth 6: "A warm, dry nose means a dog is sick."</h3>
      <p><strong>The Truth:</strong> A dog's nose temperature and moisture can vary throughout the day and isn't a reliable indicator of health. Look for other signs of illness like changes in appetite, energy level, or bathroom habits.</p>
      
      <h3>Myth 7: "Cats purr only when they're happy."</h3>
      <p><strong>The Truth:</strong> While cats often purr when content, they also purr when stressed, in pain, or even when giving birth. It's thought that purring may help cats self-soothe and even promote healing.</p>
      
      <h3>Myth 8: "Small dogs don't need as much exercise as big dogs."</h3>
      <p><strong>The Truth:</strong> Exercise needs depend more on the breed and individual dog than size. Many small breeds like Jack Russell Terriers and Dachshunds have high energy levels and require significant daily exercise.</p>
      
      <h3>Myth 9: "Cats are nocturnal."</h3>
      <p><strong>The Truth:</strong> Cats are actually crepuscular, meaning they're most active during dawn and dusk. This is when their natural prey is most active. You can adjust your cat's schedule with interactive play sessions during the day.</p>
      
      <h3>Myth 10: "Dogs are colorblind."</h3>
      <p><strong>The Truth:</strong> Dogs can see colors, just not the same range as humans. They see primarily in shades of blue and yellow, with difficulty distinguishing between red and green.</p>
      
      <h3>Myth 11: "Indoor cats don't need vaccinations."</h3>
      <p><strong>The Truth:</strong> Even indoor cats need core vaccinations as they can be exposed to diseases through open windows, other pets, or if they accidentally get outside. Rabies vaccination is also required by law in many areas, regardless of whether a cat goes outside.</p>
      
      <h3>Myth 12: "A dog's mouth is cleaner than a human's."</h3>
      <p><strong>The Truth:</strong> Both dogs and humans have numerous bacteria in their mouths, just different types. While some bacteria in dog mouths can be harmful to humans (and vice versa), the idea that a dog's mouth is "cleaner" is a myth.</p>
      
      <h3>Myth 13: "Cats hate water."</h3>
      <p><strong>The Truth:</strong> While many cats dislike being bathed, some breeds (like Turkish Vans and Bengals) enjoy water. Even cats that don't like being submerged may enjoy playing with dripping faucets or shallow water.</p>
      
      <h3>Myth 14: "Dogs feel guilty when they've done something wrong."</h3>
      <p><strong>The Truth:</strong> That "guilty look" is actually a reaction to your body language. Dogs are responding to your upset tone and posture, not feeling guilt in the human sense. They don't have the cognitive ability to reflect on past actions with guilt.</p>
      
      <h3>Myth 15: "Pets age seven years for every human year."</h3>
      <p><strong>The Truth:</strong> The aging process varies by species and size. For example, the first year of a cat or small dog's life equals about 15 human years, while larger dogs age more quickly. There are now more accurate age calculators that take these factors into account.</p>
      
      <p>When in doubt about pet care advice, always consult with a licensed veterinarian or certified animal behaviorist. What works for one pet might not be appropriate for another, and professional guidance is invaluable for your pet's health and well-being.</p>
    `,
    imageUrl: '/images/placeholder-blog.svg',
    thumbnailUrl: '/images/blog/thumbnails/pet-myths-thumb.jpg',
    author: 'Dr. Rachel Kim',
    date: '2025-06-28',
    readTime: '7 min read',
    tags: ['myths', 'education', 'pet care']
  }
];
