import { useState, useEffect } from 'react';
import { BlogContentResponse, getBlogContent } from '@/lib/aiUtils';

interface UseBlogContentResult {
  content: string;
  isLoading: boolean;
  error: string | null;
  imageUrl?: string;
  imagePrompt?: string;
  metaDescription?: string;
  tags?: string[];
}

export const useBlogContent = (topic: string, initialContent: string = '', forceRefresh: boolean = false) => {
  const [result, setResult] = useState<{
    content: string;
    imageUrl?: string;
    imagePrompt?: string;
    metaDescription?: string;
    tags?: string[];
  }>({ 
    content: initialContent,
    imageUrl: undefined,
    imagePrompt: undefined,
    metaDescription: '',
    tags: []
  });
  
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchContent = async () => {
      console.log('useBlogContent: Starting content fetch for topic:', topic);
      
      // Skip if already loading
      if (isLoading) {
        console.log('useBlogContent: Already loading, skipping');
        return;
      }
      
      // Skip if we already have content and not forcing a refresh
      if (result.content && !result.content.includes('Full blog post content would go here...') && !forceRefresh) {
        console.log('useBlogContent: Using existing content, skipping fetch');
        return;
      }

      console.log('useBlogContent: Fetching content from AI...');
      setIsLoading(true);
      setError(null);

      // If we have initial content, use it immediately but still try to enhance it
      if (initialContent && !initialContent.includes('Full blog post content would go here...')) {
        setResult(prev => ({
          ...prev,
          content: initialContent
        }));
        
        // Don't return here, allow the AI enhancement to proceed
      }

      try {
        setIsLoading(true);
        const aiContent = await getBlogContent(topic);
        
        setResult({
          content: aiContent.content || initialContent || 'No content available.',
          imageUrl: aiContent.imageUrl,
          metaDescription: aiContent.metaDescription,
          tags: aiContent.tags
        });
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : String(err);
        console.error('Error fetching blog content:', {
          error: errorMessage,
          topic,
          hasInitialContent: !!initialContent,
          timestamp: new Date().toISOString()
        });
        
        setError(`Failed to load content: ${errorMessage}. Please try again later.`);
        
        // Fallback to initial content if available
        if (initialContent) {
          console.log('useBlogContent: Falling back to initial content');
          setResult(prev => ({
            ...prev,
            content: initialContent
          }));
        } else {
          setResult(prev => ({
            ...prev,
            content: `
              <div class="p-4 bg-yellow-50 border-l-4 border-yellow-400 mb-4">
                <p class="text-yellow-700">
                  <strong>Content Loading Issue:</strong> We're having trouble loading the content for this post.
                </p>
                <p class="mt-2">${err instanceof Error ? err.message : 'Please try again later.'}</p>
              </div>
            `
          }));
        }
      } finally {
        setIsLoading(false);
      }
    };

    fetchContent();
  }, [topic, initialContent]); // Only depend on topic and initialContent

  return { 
    content: result.content, 
    isLoading, 
    error,
    imageUrl: result.imageUrl,
    imagePrompt: result.imagePrompt,
    metaDescription: result.metaDescription,
    tags: result.tags,
    refresh: () => setResult(prev => ({ ...prev, content: '' })) // Reset content to trigger a refetch
  };
};

export default useBlogContent;
