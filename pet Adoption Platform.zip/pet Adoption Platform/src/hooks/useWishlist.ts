import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface Pet {
  id: string;
  name: string;
  breed: string | null;
  age: number | null;
  size: string | null;
  location: string | null;
  images: string[] | null;
  description: string | null;
  species: string;
  gender: string | null;
  health_info: string | null;
  status: string | null;
  price: number | null;
}

interface WishlistItem {
  id: string;
  pet_id: string;
  user_id: string;
  created_at: string;
  pets: Pet;
}

export const useWishlist = () => {
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>([]);
  const [wishlistPetIds, setWishlistPetIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  // Fetch user's wishlist
  const fetchWishlist = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('favorites')
        .select(`
          id,
          pet_id,
          user_id,
          created_at,
          pets (
            id,
            name,
            breed,
            age,
            size,
            location,
            images,
            description,
            species,
            gender,
            health_info,
            status,
            price
          )
        `)
        .eq('user_id', user.id);

      if (error) throw error;

      setWishlistItems(data?.map(item => ({
        ...item,
        pets: Array.isArray(item.pets) ? item.pets[0] : item.pets
      })) || []);
      setWishlistPetIds(new Set((data || []).map(item => item.pet_id)));
    } catch (error) {
      console.error('Error fetching wishlist:', error);
      toast({
        title: "Error",
        description: "Failed to fetch wishlist",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Add pet to wishlist
  const addToWishlist = async (petId: string) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to add pets to your wishlist",
        variant: "destructive",
      });
      return;
    }

    // Check if already in wishlist
    if (wishlistPetIds.has(petId)) {
      toast({
        title: "Already in Wishlist",
        description: "This pet is already in your wishlist",
        variant: "default",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('favorites')
        .insert({
          pet_id: petId,
          user_id: user.id
        });

      if (error) throw error;

      // Update local state
      setWishlistPetIds(prev => new Set(prev).add(petId));
      
      toast({
        title: "Added to Wishlist",
        description: "Pet has been added to your wishlist",
        variant: "default",
      });

      // Refresh wishlist to get full pet details
      fetchWishlist();
    } catch (error: any) {
      // Log the full error object and stringified version
      console.error('Error adding to wishlist:', error, JSON.stringify(error));
      toast({
        title: "Error",
        description: error?.message || error?.details || JSON.stringify(error),
        variant: "destructive",
      });
    }
  };

  // Remove pet from wishlist
  const removeFromWishlist = async (petId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('favorites')
        .delete()
        .eq('pet_id', petId)
        .eq('user_id', user.id);

      if (error) throw error;

      // Update local state
      setWishlistPetIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(petId);
        return newSet;
      });

      setWishlistItems(prev => prev.filter(item => item.pet_id !== petId));

      toast({
        title: "Removed from Wishlist",
        description: "Pet has been removed from your wishlist",
        variant: "default",
      });
    } catch (error) {
      console.error('Error removing from wishlist:', error);
      toast({
        title: "Error",
        description: "Failed to remove pet from wishlist",
        variant: "destructive",
      });
    }
  };

  // Toggle wishlist status
  const toggleWishlist = async (petId: string) => {
    if (wishlistPetIds.has(petId)) {
      await removeFromWishlist(petId);
    } else {
      await addToWishlist(petId);
    }
  };

  // Check if pet is in wishlist
  const isInWishlist = (petId: string) => {
    return wishlistPetIds.has(petId);
  };

  useEffect(() => {
    if (user) {
      fetchWishlist();
    } else {
      setWishlistItems([]);
      setWishlistPetIds(new Set());
    }
  }, [user]);

  return {
    wishlistItems,
    loading,
    addToWishlist,
    removeFromWishlist,
    toggleWishlist,
    isInWishlist,
    fetchWishlist
  };
};