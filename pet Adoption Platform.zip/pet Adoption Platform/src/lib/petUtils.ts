import { supabase } from '@/integrations/supabase/client';

/**
 * Updates the price of a pet in the database
 * @param petId The ID of the pet to update
 * @param price The new price to set
 * @returns Promise with the update result
 */
export const updatePetPrice = async (petId: string, price: number) => {
  try {
    const { data, error } = await supabase
      .from('pets')
      .update({ price })
      .eq('id', petId)
      .select()
      .single();

    if (error) throw error;
    return { success: true, data };
  } catch (error) {
    console.error('Error updating pet price:', error);
    return { success: false, error };
  }
};

/**
 * Gets the price for a pet by name
 * @param petName The name of the pet
 * @returns The price or undefined if not found
 */
export const getPriceForPet = (petName: string): number | undefined => {
  const petPrices: Record<string, number> = {
    'Buddy': 15000,
    'Whiskers': 8000,
    'Max': 12000,
    'Luna': 10000,
    'Shadow': 6000,
    'Charlie': 9000
  };

  return petPrices[petName];
};
