// This file contains utility functions for blog content generation
// Note: AI content generation has been disabled in favor of static content

// Cache to store generated content
const contentCache = new Map<string, Promise<BlogContentResponse>>();

export interface BlogContentResponse {
  title: string;
  content: string;
  metaDescription: string;
  tags: string[];
  imageUrl?: string;
}

// Generate static blog content (placeholder function)
export const generateBlogContent = async (topic: string): Promise<BlogContentResponse> => {
  console.log('Using static content for topic:', topic);
  
  return {
    title: `Guide to ${topic}`,
    content: `
      <div class="prose max-w-none">
        <p>This is a static blog post about ${topic}.</p>
        <p>Please check back later for more content on this topic.</p>
      </div>
    `,
    metaDescription: `Learn more about ${topic} with our comprehensive guide.`,
    tags: [topic.toLowerCase().replace(/\s+/g, '-')],
    imageUrl: '/images/placeholder-blog.svg'
  };
};

export const getBlogContent = async (topic: string): Promise<BlogContentResponse> => {
  // Check cache first
  const cacheKey = topic.toLowerCase().trim();
  
  if (contentCache.has(cacheKey)) {
    return contentCache.get(cacheKey)!;
  }

  // If not in cache, generate static content
  const contentPromise = generateBlogContent(topic);
  contentCache.set(cacheKey, contentPromise);

  return contentPromise;
};

// Function to get a static placeholder image for a topic
export const getBlogImage = async (topic: string): Promise<{ url: string; prompt: string }> => {
  return {
    url: '/images/placeholder-blog.svg',
    prompt: 'Static placeholder image'
  };
};
