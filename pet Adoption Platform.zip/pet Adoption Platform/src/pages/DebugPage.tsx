import React, { useEffect, useState } from 'react';

const DebugPage = () => {
  const [envVars, setEnvVars] = useState<Record<string, any>>({});
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkEnv = async () => {
      try {
        // Test if we can access the environment variables
        const vars = {
          VITE_OPENAI_API_KEY: import.meta.env.VITE_OPENAI_API_KEY 
            ? '✅ Set (first few chars: ' + String(import.meta.env.VITE_OPENAI_API_KEY).substring(0, 3) + '...)' 
            : '❌ Not Set',
          NODE_ENV: import.meta.env.MODE,
          BASE_URL: import.meta.env.BASE_URL,
          // Add any other environment variables you want to check
        };
        
        setEnvVars(vars);
        
        // Try a simple fetch to see if the API key works
        if (import.meta.env.VITE_OPENAI_API_KEY) {
          const response = await fetch('https://api.openai.com/v1/engines', {
            headers: {
              'Authorization': `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
              'Content-Type': 'application/json'
            }
          });
          
          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`API Error: ${errorData.error?.message || 'Unknown error'}`);
          }
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error occurred');
      } finally {
        setIsLoading(false);
      }
    };

    checkEnv();
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p>Checking environment configuration...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Environment Debug</h1>
      
      {error && (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
          <p className="font-bold">Error</p>
          <p>{error}</p>
        </div>
      )}
      
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Environment Variables</h2>
        <div className="space-y-2">
          {Object.entries(envVars).map(([key, value]) => (
            <div key={key} className="flex border-b border-gray-100 py-2">
              <span className="font-mono font-semibold w-48">{key}:</span>
              <span className="font-mono">{String(value)}</span>
            </div>
          ))}
        </div>
        
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Next Steps</h2>
          <ul className="list-disc pl-5 space-y-2">
            <li>Make sure your <code className="bg-gray-100 px-1 rounded">.env</code> file is in the root of your project</li>
            <li>Ensure the file contains <code className="bg-gray-100 px-1 rounded">VITE_OPENAI_API_KEY=your_key_here</code></li>
            <li>Restart your development server after making changes to <code className="bg-gray-100 px-1 rounded">.env</code></li>
            <li>Check for any typos in your environment variable names</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default DebugPage;
