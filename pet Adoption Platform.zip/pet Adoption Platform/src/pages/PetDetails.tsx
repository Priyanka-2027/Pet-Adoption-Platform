import { useParams, useNavigate, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useWishlist } from "@/hooks/useWishlist";
import { getPriceForPet, updatePetPrice } from "@/lib/petUtils";
import { toast } from "@/components/ui/use-toast";
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import { Navigation, Pagination } from 'swiper/modules';

const dummyImages = [
  'https://images.unsplash.com/photo-1518717758536-85ae29035b6d',
  'https://images.unsplash.com/photo-1518715308788-3005759c61d4',
  'https://images.unsplash.com/photo-1507146426996-ef05306b995a',
];

const PetDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [pet, setPet] = useState(location.state?.pet || null);
  const [loading, setLoading] = useState(!location.state?.pet);
  const [error, setError] = useState(null);
  const { addToWishlist, isInWishlist } = useWishlist();

  useEffect(() => {
    const fetchPet = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("pets")
        .select("*")
        .eq("id", id)
        .single();
      if (error) {
        setError(error.message);
      } else {
        setPet(data);
      }
      setLoading(false);
    };
    fetchPet();
  }, [id]);

  const handleAdoptNow = async () => {
    if (!pet) return;
    
    // If price is missing, try to update it before navigating
    if (pet.price === null || pet.price === undefined) {
      const price = getPriceForPet(pet.name);
      if (price !== undefined) {
        const { success, data } = await updatePetPrice(pet.id, price);
        if (success && data) {
          setPet({ ...pet, price: data.price });
          toast({
            title: "Pet information updated",
            description: `Price updated for ${pet.name}`,
          });
        }
      }
    }
    
    navigate(`/adopt/${pet.id}`, { state: { pet } });
  };

  if (loading) return <div className="text-center py-8">Loading...</div>;
  if (error) return <div className="text-center py-8 text-red-500">{error}</div>;
  if (!pet) return <div className="text-center py-8">Pet not found.</div>;

  // Use pet.images if available, otherwise dummy images
  const images = pet.images && pet.images.length > 0 ? pet.images : dummyImages;

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-8 bg-white rounded-lg shadow-lg mt-8">
      {/* Image Carousel */}
      <Swiper
        modules={[Navigation, Pagination]}
        navigation
        pagination={{ clickable: true }}
        className="mb-6 rounded-lg overflow-hidden"
      >
        {images.map((img, idx) => (
          <SwiperSlide key={idx}>
            <img src={img} alt={pet.name} className="w-full h-72 object-cover" />
          </SwiperSlide>
        ))}
      </Swiper>

      {/* Pet Details */}
      <div className="flex justify-between items-start mb-2">
        <h1 className="text-3xl font-bold">{pet.name}</h1>
        {pet.price && (
          <div className="bg-orange-100 text-orange-700 px-4 py-2 rounded-full text-lg font-semibold">
            ₹{pet.price.toLocaleString('en-IN')}
          </div>
        )}
      </div>
      <div className="flex flex-wrap gap-2 mb-4 text-gray-600 text-sm">
        <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full">{pet.age} {pet.age === 1 ? 'year' : 'years'}</span>
        <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full">{pet.breed}</span>
        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full">{pet.gender}</span>
        <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full">{pet.size}</span>
        <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full">{pet.location}</span>
      </div>
      <div className="mb-4 text-gray-700 text-base leading-relaxed">{pet.description}</div>

      {/* Extra Statuses */}
      <div className="flex flex-wrap gap-4 mb-6">
        <div className="flex items-center gap-2">
          <span className={`w-3 h-3 rounded-full ${pet.vaccinated ? 'bg-green-500' : 'bg-red-400'}`}></span>
          <span>Vaccinated: <b>{pet.vaccinated ? 'Yes' : 'No'}</b></span>
        </div>
        <div className="flex items-center gap-2">
          <span className={`w-3 h-3 rounded-full ${pet.trained ? 'bg-green-500' : 'bg-red-400'}`}></span>
          <span>Trained: <b>{pet.trained ? 'Yes' : 'No'}</b></span>
        </div>
        <div className="flex items-center gap-2">
          <span className={`w-3 h-3 rounded-full ${pet.kid_friendly ? 'bg-green-500' : 'bg-red-400'}`}></span>
          <span>Kid Friendly: <b>{pet.kid_friendly ? 'Yes' : 'No'}</b></span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <button
          className="flex-1 bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-lg shadow transition"
          onClick={handleAdoptNow}
        >
          Adopt Now
        </button>
        <button
          className={`flex-1 border-2 border-orange-500 text-orange-500 font-bold py-3 rounded-lg shadow transition ${isInWishlist(pet.id) ? 'bg-orange-100' : 'bg-white'}`}
          onClick={() => addToWishlist(pet.id)}
        >
          {isInWishlist(pet.id) ? 'In Wishlist' : 'Add to Wishlist'}
        </button>
      </div>
    </div>
  );
};

export default PetDetails; 