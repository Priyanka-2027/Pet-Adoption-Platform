import { useLocation, useParams, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/use-toast';

const AdoptionForm = () => {
  const { petId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const pet = location.state?.pet;
  console.log('AdoptionForm pet:', pet);

  const [form, setForm] = useState({
    name: '',
    email: '',
    address: '',
    phone: '',
    reason: '',
    homeVisitDate: '',
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call - replace with your actual API endpoint
    const { error } = await supabase.from('adoptions').insert([
      {
        pet_id: petId,
        adopter_name: form.name,
        adopter_email: form.email,
        adopter_address: form.address,
        adopter_phone: form.phone,
        reason: form.reason,
        home_visit_date: form.homeVisitDate,
      },
    ]);
    setLoading(false);
    if (error) {
      toast({ title: 'Submission Failed', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Application Submitted!', description: 'Your adoption application has been received.' });
      navigate('/confirmation');
    }
  };

  if (!pet) {
    return <div className="text-center py-8">Pet details not found.</div>;
  }

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-8 bg-white rounded-lg shadow-lg mt-8">
      <div className="flex flex-col items-center mb-6">
        <img src={pet.images && pet.images.length > 0 ? pet.images[0] : '/placeholder.jpg'} alt={pet.name} className="w-48 h-48 object-cover rounded-lg mb-2" />
        <h1 className="text-2xl font-bold">{pet.name}</h1>
        <div className="flex flex-wrap gap-2 text-gray-600 text-sm mt-2">
          <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full">{pet.age} {pet.age === 1 ? 'year' : 'years'}</span>
          <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full">{pet.breed}</span>
          <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full">{pet.gender}</span>
          <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full">{pet.size}</span>
          <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full">{pet.location}</span>
        </div>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input name="name" value={form.name} onChange={handleChange} required placeholder="Your Name" className="w-full border rounded px-3 py-2" />
        <input name="email" value={form.email} onChange={handleChange} required type="email" placeholder="Email" className="w-full border rounded px-3 py-2" />
        <input name="address" value={form.address} onChange={handleChange} required placeholder="Address" className="w-full border rounded px-3 py-2" />
        <input name="phone" value={form.phone} onChange={handleChange} required placeholder="Phone" className="w-full border rounded px-3 py-2" />
        <textarea name="reason" value={form.reason} onChange={handleChange} required placeholder="Reason for Adoption" className="w-full border rounded px-3 py-2" />
        <div className="space-y-1">
          <label htmlFor="homeVisitDate" className="block text-sm font-medium text-gray-700">
            When are you available for home visiting?
          </label>
          <input 
            id="homeVisitDate"
            name="homeVisitDate" 
            value={form.homeVisitDate} 
            onChange={handleChange} 
            required 
            type="date" 
            className="w-full border rounded px-3 py-2" 
          />
        </div>
        <button type="submit" disabled={loading} className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-lg shadow transition">
          {loading ? 'Submitting...' : 'Submit Application'}
        </button>
      </form>
    </div>
  );
};

export default AdoptionForm; 