import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/use-toast';
import { saveAs } from 'file-saver';

interface AdoptionApplication {
  id: string;
  pet_id: string;
  adopter_name: string;
  adopter_email: string;
  adopter_address: string;
  adopter_phone: string;
  reason: string | null;
  home_visit_date: string | null;
  status: string | null;
  created_at: string;
  pet?: {
    name: string;
    breed: string;
    images: string[] | null;
  };
}

const AdminDashboard = () => {
  const [applications, setApplications] = useState<AdoptionApplication[]>([]);
  const [filteredApplications, setFilteredApplications] = useState<AdoptionApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    fetchApplications();
  }, []);

  useEffect(() => {
    filterApplications();
  }, [applications, searchTerm, statusFilter]);

  const fetchApplications = async () => {
    try {
      const { data, error } = await supabase
        .from('adoptions')
        .select(`
          *,
          pet:pets(name, breed, images)
        `)
        .order('created_at', { ascending: false });

      if (error) {
        toast({ title: 'Error', description: error.message, variant: 'destructive' });
      } else {
        setApplications(data || []);
      }
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to fetch applications', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const filterApplications = () => {
    let filtered = applications;

    // Filter by status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(app => app.status === statusFilter);
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(app => 
        app.adopter_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.adopter_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.pet?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.pet?.breed.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredApplications(filtered);
  };

  const handleStatusUpdate = async (applicationId: string, status: 'approved' | 'rejected') => {
    try {
      const { error } = await supabase
        .from('adoptions')
        .update({ status })
        .eq('id', applicationId);

      if (error) {
        toast({ title: 'Error', description: error.message, variant: 'destructive' });
      } else {
        toast({ title: 'Success', description: `Application ${status}` });
        
        // Send email notification
        await sendEmailNotification(applicationId, status);
        
        fetchApplications(); // Refresh the list
      }
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to update status', variant: 'destructive' });
    }
  };

  const sendEmailNotification = async (applicationId: string, status: 'approved' | 'rejected') => {
    const application = applications.find(app => app.id === applicationId);
    if (!application) return;

    try {
      // This would typically call your email service (SendGrid, AWS SES, etc.)
      // For now, we'll simulate it with a console log
      console.log(`Email notification sent to ${application.adopter_email}: Application ${status}`);
      
      // You can integrate with your email service here
      // Example with a hypothetical email service:
      // await emailService.send({
      //   to: application.adopter_email,
      //   subject: `Adoption Application ${status.charAt(0).toUpperCase() + status.slice(1)}`,
      //   body: `Dear ${application.adopter_name}, your adoption application for ${application.pet?.name} has been ${status}.`
      // });
      
      toast({ 
        title: 'Email Sent', 
        description: `Notification sent to ${application.adopter_email}` 
      });
    } catch (error) {
      console.error('Failed to send email notification:', error);
    }
  };

  const getStatusBadge = (status: string | null) => {
    switch (status) {
      case 'approved':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Approved</span>;
      case 'rejected':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">Rejected</span>;
      default:
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">Pending</span>;
    }
  };

  const exportToCSV = () => {
    const headers = [
      'Pet Name', 'Pet Breed', 'Adopter Name', 'Adopter Email', 'Adopter Address', 'Adopter Phone', 'Reason', 'Home Visit Date', 'Status', 'Submitted'
    ];
    const rows = filteredApplications.map(app => [
      app.pet?.name || '',
      app.pet?.breed || '',
      app.adopter_name,
      app.adopter_email,
      app.adopter_address,
      app.adopter_phone,
      app.reason || '',
      app.home_visit_date || '',
      app.status || 'pending',
      new Date(app.created_at).toLocaleString()
    ]);
    const csvContent = [headers, ...rows].map(e => e.map(v => `"${(v || '').toString().replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    saveAs(blob, `adoption_applications_${new Date().toISOString().slice(0,10)}.csv`);
  };

  if (loading) {
    return <div className="text-center py-8">Loading applications...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-8">
      <h1 className="text-3xl font-bold mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <span>Adoption Applications</span>
        <button
          onClick={exportToCSV}
          className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-4 rounded shadow transition"
        >
          Export CSV
        </button>
      </h1>
      
      {/* Search and Filter Controls */}
      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <input
            type="text"
            placeholder="Search by adopter name, email, or pet name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          />
        </div>
        <div className="sm:w-48">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Statistics */}
      <div className="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-2xl font-bold text-gray-900">{applications.length}</div>
          <div className="text-sm text-gray-500">Total Applications</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-2xl font-bold text-yellow-600">
            {applications.filter(app => !app.status).length}
          </div>
          <div className="text-sm text-gray-500">Pending</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-2xl font-bold text-green-600">
            {applications.filter(app => app.status === 'approved').length}
          </div>
          <div className="text-sm text-gray-500">Approved</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-2xl font-bold text-red-600">
            {applications.filter(app => app.status === 'rejected').length}
          </div>
          <div className="text-sm text-gray-500">Rejected</div>
        </div>
      </div>
      
      {filteredApplications.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          {applications.length === 0 ? 'No adoption applications found.' : 'No applications match your search criteria.'}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Pet
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Adopter
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Contact
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Home Visit Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Submitted
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredApplications.map((application) => (
                  <tr key={application.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <img
                            className="h-10 w-10 rounded-full object-cover"
                            src={application.pet?.images?.[0] || '/placeholder.jpg'}
                            alt={application.pet?.name}
                          />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {application.pet?.name}
                          </div>
                          <div className="text-sm text-gray-500">
                            {application.pet?.breed}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {application.adopter_name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {application.adopter_address}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {application.adopter_email}
                      </div>
                      <div className="text-sm text-gray-500">
                        {application.adopter_phone}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {getStatusBadge(application.status)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {application.home_visit_date ? new Date(application.home_visit_date).toLocaleDateString() : 'Not specified'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(application.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        {!application.status && (
                          <>
                            <button
                              onClick={() => handleStatusUpdate(application.id, 'approved')}
                              className="text-green-600 hover:text-green-900 bg-green-100 hover:bg-green-200 px-3 py-1 rounded-md text-xs"
                            >
                              Approve
                            </button>
                            <button
                              onClick={() => handleStatusUpdate(application.id, 'rejected')}
                              className="text-red-600 hover:text-red-900 bg-red-100 hover:bg-red-200 px-3 py-1 rounded-md text-xs"
                            >
                              Reject
                            </button>
                          </>
                        )}
                        <button
                          onClick={() => {
                            // Show detailed view
                            alert(`Reason for adoption: ${application.reason || 'Not provided'}`);
                          }}
                          className="text-blue-600 hover:text-blue-900 bg-blue-100 hover:bg-blue-200 px-3 py-1 rounded-md text-xs"
                        >
                          View Details
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard; 