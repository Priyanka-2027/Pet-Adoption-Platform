import { Link } from 'react-router-dom';

const TermsOfService = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-foreground mb-4">Terms of Service</h1>
        <p className="text-muted-foreground">Last Updated: July 31, 2024</p>
      </div>

      <div className="prose prose-lg max-w-none text-foreground">
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">1. Acceptance of Terms</h2>
          <p className="mb-4">
            By accessing or using the PawMatch platform ("Service"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, you may not use our Service.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">2. Description of Service</h2>
          <p className="mb-4">
            PawMatch is a platform that connects potential pet adopters with animal shelters and rescue organizations. We facilitate the process of pet adoption but are not responsible for the adoption process itself.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">3. User Accounts</h2>
          <p className="mb-4">To use certain features of our Service, you must create an account. You agree to:</p>
          <ul className="list-disc pl-6 mb-4 space-y-2">
            <li>Provide accurate and complete information</li>
            <li>Maintain the security of your account credentials</li>
            <li>Be responsible for all activities that occur under your account</li>
            <li>Immediately notify us of any unauthorized use of your account</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">4. Pet Listings</h2>
          <p className="mb-4">
            While we strive to provide accurate information about pets available for adoption, we cannot guarantee the accuracy, completeness, or reliability of any pet listings. The final decision to adopt a pet is solely between you and the shelter or rescue organization.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">5. User Conduct</h2>
          <p className="mb-4">You agree not to:</p>
          <ul className="list-disc pl-6 mb-4 space-y-2">
            <li>Use the Service for any illegal purpose</li>
            <li>Harass, threaten, or intimidate other users or shelter staff</li>
            <li>Post false or misleading information</li>
            <li>Impersonate any person or entity</li>
            <li>Interfere with or disrupt the Service</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">6. Limitation of Liability</h2>
          <p className="mb-4">
            To the maximum extent permitted by law, PawMatch shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of or inability to use the Service.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">7. Changes to Terms</h2>
          <p className="mb-4">
            We reserve the right to modify these Terms at any time. We will provide notice of significant changes through our Service. Your continued use of the Service after such changes constitutes your acceptance of the new Terms.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">8. Contact Us</h2>
          <p>
            If you have any questions about these Terms, please contact us at{' '}
            <a href="mailto:terms@pawmatch.in" className="text-primary hover:underline">terms@pawmatch.in</a>.
          </p>
        </section>
      </div>

      <div className="mt-12 text-center">
        <Link 
          to="/" 
          className="inline-flex items-center justify-center px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-200 font-medium"
        >
          <span className="mr-2">&larr;</span> Back to Home
        </Link>
      </div>
    </div>
  );
};

export default TermsOfService;
