import { sampleBlogPosts } from '@/types/blog';
import BlogList from '@/components/blog/BlogList';
import { BlogPost } from '@/types/blog';
import { Link } from 'react-router-dom';

const BlogPage = () => {
  // Use static blog posts with proper image handling
  const posts: BlogPost[] = sampleBlogPosts.map(post => ({
    ...post,
    imageUrl: post.imageUrl || '/images/placeholder-blog.svg',
    thumbnailUrl: post.thumbnailUrl || post.imageUrl || '/images/placeholder-blog.svg',
    content: post.content || `This is a static blog post about ${post.title}.`,
    metaDescription: post.metaDescription || post.excerpt || `Learn more about ${post.title}`,
    tags: post.tags || [post.title.toLowerCase().replace(/\s+/g, '-')]
  }));

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Pet Care Blog</h1>
      <BlogList posts={posts} />
      <div className="mt-12 text-center">
        <Link 
          to="/" 
          className="inline-flex items-center justify-center px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-200 font-medium"
        >
          <span className="mr-2">&larr;</span> Back to Home
        </Link>
      </div>
    </main>
  );
};

export default BlogPage;
