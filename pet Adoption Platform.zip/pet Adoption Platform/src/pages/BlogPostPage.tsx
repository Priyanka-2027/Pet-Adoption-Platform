import { useParams, Link } from 'react-router-dom';
import { sampleBlogPosts } from '@/types/blog';
import { Button } from '@/components/ui/button';
import { ArrowLeft, CalendarDays, Clock, User, Image as ImageIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const BlogPostPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const post = sampleBlogPosts.find(p => p.id === id) || null;

  // If no post is found, show error
  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Post not found</h1>
          <Button onClick={() => navigate('/blog')} variant="outline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Blog
          </Button>
        </div>
      </div>
    );
  }

  const relatedPosts = sampleBlogPosts.filter(p => p.id !== post.id).slice(0, 2);

  return (
    <article className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <Button 
        onClick={() => navigate(-1)} 
        variant="ghost" 
        className="mb-8 group flex items-center hover:bg-orange-50 transition-colors duration-200"
      >
        <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
        <span className="text-orange-600 font-medium">Back to Blog</span>
      </Button>

      <div className="mb-12">
        <div className="flex flex-wrap gap-2 mb-6">
          {post.tags?.map((tag) => (
            <span 
              key={tag} 
              className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-orange-50 text-orange-700 hover:bg-orange-100 transition-colors duration-200"
            >
              {tag}
            </span>
          )) || []}
        </div>
        
        <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl mb-6 leading-tight">
          {post.title}
        </h1>
        
        <div className="flex flex-wrap items-center text-gray-600 text-sm mb-8 gap-4">
          <div className="flex items-center bg-gray-50 px-3 py-1.5 rounded-full">
            <User className="h-4 w-4 mr-1.5 text-orange-500" />
            <span className="font-medium">{post.author}</span>
          </div>
          <div className="flex items-center bg-gray-50 px-3 py-1.5 rounded-full">
            <CalendarDays className="h-4 w-4 mr-1.5 text-orange-500" />
            <span>{new Date(post.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
          </div>
          <div className="flex items-center bg-gray-50 px-3 py-1.5 rounded-full">
            <Clock className="h-4 w-4 mr-1.5 text-orange-500" />
            <span>{post.readTime}</span>
          </div>
        </div>
        
        <div className="relative rounded-2xl overflow-hidden mb-12 shadow-lg bg-gray-100 transition-all duration-300 hover:shadow-xl">
          <div className="relative w-full pt-[56.25%] overflow-hidden">
            <img
              src={post.imageUrl || post.thumbnailUrl || '/images/placeholder-blog.svg'}
              alt={post.title}
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 hover:scale-105"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                if (target.src !== '/images/placeholder-blog.svg') {
                  target.src = '/images/placeholder-blog.svg';
                  target.className = 'absolute inset-0 w-full h-full object-contain p-8';
                }
              }}
              loading="eager"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
              <div className="flex flex-wrap gap-2">
                {post.tags?.slice(0, 3).map((tag) => (
                  <span 
                    key={tag} 
                    className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-white/90 text-orange-700 backdrop-blur-sm"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="blog-content max-w-3xl mx-auto">
          <div dangerouslySetInnerHTML={{ __html: post.content }} />
        </div>
      </div>
      
      <div className="mt-16 pt-12 border-t border-gray-100">
        <h2 className="text-2xl font-bold mb-8 text-gray-800">You might also like</h2>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-2">
          {relatedPosts.map((relatedPost) => (
            <div key={relatedPost.id} className="group bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300 border border-gray-100 hover:border-orange-50">
              <Link 
                to={`/blog/${relatedPost.id}`}
                className="h-full flex flex-col"
              >
                <div className="h-48 overflow-hidden relative bg-gray-50">
                  <img
                    src={relatedPost.thumbnailUrl || relatedPost.imageUrl || '/images/placeholder-blog.svg'}
                    alt={relatedPost.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      if (target.src !== '/images/placeholder-blog.svg') {
                        target.src = '/images/placeholder-blog.svg';
                        target.className = 'w-full h-full object-contain p-8';
                      }
                    }}
                    loading="lazy"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="text-lg font-semibold mb-2 text-gray-900 group-hover:text-orange-600 transition-colors">
                    {relatedPost.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                    {relatedPost.excerpt}
                  </p>
                  <div className="mt-auto pt-4 border-t border-gray-100">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-xs text-gray-500">
                        <CalendarDays className="h-3.5 w-3.5 mr-1 text-orange-500" />
                        <span>{new Date(relatedPost.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                      </div>
                      <span className="text-sm font-medium text-orange-600 group-hover:underline">
                        Read more
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-16 flex justify-center">
        <Button 
          onClick={() => navigate('/blog')} 
          variant="outline" 
          className="flex items-center group px-6 py-6 border-2 border-orange-100 hover:border-orange-200 bg-orange-50 hover:bg-orange-50 transition-all duration-200"
        >
          <ArrowLeft className="mr-3 h-5 w-5 text-orange-600 group-hover:-translate-x-1 transition-transform" />
          <span className="text-orange-700 font-semibold">Back to Articles</span>
        </Button>
      </div>
    </article>
  );
};

export default BlogPostPage;
