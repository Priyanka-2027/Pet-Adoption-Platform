import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PetCard from "@/components/PetCard";
import { useWishlist } from "@/hooks/useWishlist";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const Wishlist = () => {
  const { wishlistItems, loading } = useWishlist();
  const { user } = useAuth();

  
  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <Heart className="w-16 h-16 text-muted-foreground mx-auto mb-6" />
            <h1 className="text-3xl font-bold text-foreground mb-4">
              Sign In to View Your Wishlist
            </h1>
            <p className="text-muted-foreground mb-8">
              Create an account or sign in to save your favorite pets and access your wishlist.
            </p>
            <div className="flex gap-4 justify-center">
              <Button asChild>
                <Link to="/auth">Sign In</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/">Browse Pets</Link>
              </Button>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-16">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
            <p className="text-muted-foreground mt-4">Loading your wishlist...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link to="/" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>
          </Button>
          
          <div className="flex items-center gap-3 mb-4">
            <Heart className="w-8 h-8 text-primary fill-current" />
            <h1 className="text-3xl md:text-4xl font-bold text-foreground">
              My Wishlist
            </h1>
          </div>
          
          <p className="text-muted-foreground">
            {wishlistItems.length === 0 
              ? "You haven't saved any pets yet. Start browsing to find your perfect companion!"
              : `You have ${wishlistItems.length} ${wishlistItems.length === 1 ? 'pet' : 'pets'} saved in your wishlist.`
            }
          </p>
        </div>

        {wishlistItems.length === 0 ? (
          /* Empty State */
          <Card className="bg-card border-border">
            <CardContent className="p-12 text-center">
              <Heart className="w-16 h-16 text-muted-foreground mx-auto mb-6" />
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                Your Wishlist is Empty
              </h2>
              <p className="text-muted-foreground mb-8 max-w-md mx-auto">
                Start exploring our amazing pets and save your favorites by clicking the heart icon on any pet card.
              </p>
              <div className="flex gap-4 justify-center">
                <Button asChild>
                  <Link to="/">Browse Pets</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link to="/search">Use AI Search</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          /* Wishlist Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {wishlistItems.map((item) => (
              <PetCard key={item.id} pet={item.pets} />
            ))}
          </div>
        )}

        {/* Action Buttons */}
        {wishlistItems.length > 0 && (
          <div className="text-center mt-12">
            <div className="flex gap-4 justify-center">
              <Button asChild>
                <Link to="/">Continue Browsing</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/search">Find More Pets</Link>
              </Button>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default Wishlist;