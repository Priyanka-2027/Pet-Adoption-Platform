import { Link } from 'react-router-dom';
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AISearch from "@/components/AISearch";

const Search = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="py-16">
        <div className="container mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold mb-4">Find Your Perfect Pet</h1>
            <p className="text-xl text-muted-foreground">
              Use AI to search for pets that match exactly what you're looking for
            </p>
          </div>
          <AISearch />
          <div className="mt-12 text-center">
            <Link 
              to="/" 
              className="inline-flex items-center justify-center px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors duration-200 font-medium"
            >
              <span className="mr-2">&larr;</span> Back to Home
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Search;